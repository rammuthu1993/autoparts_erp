package com.autoparts.erp.ai.config;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Provides a dedicated JDBC path for AI lookup tools. In production this must
 * use a database identity granted SELECT-only privileges. The non-production
 * profile retains the shared datasource for backwards-compatible local setup.
 */
@Configuration
public class AiToolJdbcConfiguration {

    private static final int QUERY_TIMEOUT_SECONDS = 15;

    @Bean(name = "aiToolDataSource", destroyMethod = "close")
    @Profile("prod")
    public HikariDataSource productionAiToolDataSource(
            @Value("${app.ai.datasource.url}") String url,
            @Value("${app.ai.datasource.username}") String username,
            @Value("${app.ai.datasource.password}") String password) {

        HikariDataSource dataSource = DataSourceBuilder.create()
                .type(HikariDataSource.class)
                .driverClassName("org.postgresql.Driver")
                .url(url)
                .username(username)
                .password(password)
                .build();
        dataSource.setPoolName("ai-tool-readonly-pool");
        dataSource.setMaximumPoolSize(3);
        dataSource.setMinimumIdle(0);
        dataSource.setConnectionTimeout(5_000);
        dataSource.setValidationTimeout(3_000);
        dataSource.setMaxLifetime(1_500_000);
        dataSource.setReadOnly(true);
        return dataSource;
    }

    @Bean(name = "aiToolDataSource")
    @Profile("!prod")
    public DataSource developmentAiToolDataSource(DataSource applicationDataSource) {
        return applicationDataSource;
    }

    @Bean("aiToolJdbcTemplate")
    public JdbcTemplate aiToolJdbcTemplate(
            @Qualifier("aiToolDataSource") DataSource dataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        jdbcTemplate.setQueryTimeout(QUERY_TIMEOUT_SECONDS);
        jdbcTemplate.setMaxRows(500);
        return jdbcTemplate;
    }
}
