# Phase 4 Production Readiness — Integrated Code Changes

This document accompanies the Phase 4 source bundle.

## Included implementation

- Removed the hardcoded demo password and BCrypt output from application startup.
- Added explicit `dev` and `prod` property profiles.
- Kept the existing local secrets-file import only in the `dev` profile.
- Changed the common Flyway baseline default to `false`; the `dev` profile retains the existing local baseline behavior. The `prod` profile disables automatic baselining and Flyway clean.
- Added production AI-tool datasource separation. Under `prod`, AI lookup tools use `AI_TOOL_DB_URL`, `AI_TOOL_DB_USERNAME`, and `AI_TOOL_DB_PASSWORD`; the datasource is configured read-only and has a small bounded pool. Under non-production profiles, the existing shared datasource remains for compatibility.
- Added a 15-second query timeout and 500-row JdbcTemplate maximum for AI lookup queries.
- Added explicit CORS allowlist configuration.
- Sanitized AI provider errors and unexpected server exceptions returned to API clients.
- Added health/info/metrics actuator exposure; existing Spring Security still protects non-public actuator endpoints.
- Added PostgreSQL commands for provisioning a dedicated AI reader role.

## Required production environment variables

```text
SPRING_PROFILES_ACTIVE=prod
DB_URL=jdbc:postgresql://HOST:5432/autoparts_erp
DB_USERNAME=APPLICATION_DATABASE_ROLE
DB_PASSWORD=APPLICATION_DATABASE_PASSWORD
JWT_SECRET=BASE64_ENCODED_RANDOM_SECRET_AT_LEAST_32_BYTES
SARVAM_API_KEY=PROVIDER_API_KEY
AI_TOOL_DB_URL=jdbc:postgresql://HOST:5432/autoparts_erp
AI_TOOL_DB_USERNAME=autoparts_ai_reader
AI_TOOL_DB_PASSWORD=STRONG_READ_ONLY_ROLE_PASSWORD
APP_CORS_ALLOWED_ORIGINS=https://your-approved-frontend.example
```

`JWT_SECRET` must decode from Base64 to at least 32 random bytes. Use a secret manager or protected environment injection; do not commit secrets.

## Provision the AI reader

1. Determine the real owner role for application tables.
2. Edit `docs/sql/create-ai-readonly-role.sql` and replace `autoparts_erp_owner` with that role.
3. Run the script as a PostgreSQL administrator, supplying `ai_reader_password` through `psql -v`.
4. Verify that `autoparts_ai_reader` can SELECT required ERP tables and cannot INSERT, UPDATE, DELETE, TRUNCATE, CREATE or ALTER.
5. Grant access only to required views/tables if the current AI tools do not need the entire public schema. The supplied script grants SELECT on all current public tables and future tables created by the configured owner; narrow this before production if feasible.

Database-level grants are the actual security boundary. Hikari's read-only setting is additional protection, not a substitute for PostgreSQL permissions.

## Flyway migration caution

The development profile preserves the project's existing `baseline-on-migrate=true` behavior to avoid unexpectedly breaking a local manually initialized database. Production has `baseline-on-migrate=false`. Before production startup, verify that the target database has the expected `flyway_schema_history` and migration state. Do not baseline an unknown database automatically.

No existing Flyway migration was modified or added by this bundle.

## Secrets incident response

The source archive includes a local secrets file and Git history. Deleting a secrets file does not invalidate credentials that may have been exposed. Rotate database credentials and JWT signing keys before production. Rotate provider keys if they were committed or otherwise exposed. Coordinate Git history cleanup with all repository collaborators; do not rewrite a shared remote history without agreement.

## Verification

This environment has Java 21, while the project targets Java 25. The project tests were therefore not run here. Run from the project root on the user's Java 25 Windows environment:

```powershell
java -version
.\mvnw.cmd -version
.\mvnw.cmd -DskipTests compile
.\mvnw.cmd test
.\mvnw.cmd verify
```

Then test both profiles against disposable databases:

```powershell
$env:SPRING_PROFILES_ACTIVE = 'dev'
.\mvnw.cmd spring-boot:run

$env:SPRING_PROFILES_ACTIVE = 'prod'
# Set all production environment variables before starting.
.\mvnw.cmd spring-boot:run
```

Do not point integration tests or migration checks at the production database.

## Scope and remaining verification

This bundle makes the concrete source changes listed above. It does not certify the whole ERP as production-ready. Full verification is still required for refresh-token replay, every endpoint's role matrix, transactional inventory/financial concurrency, distributed rate limiting, AI global concurrency, provider retry semantics, migration compatibility against a production-like database, and live SARVAM grounded-answer quality. The deferred Phase 5 semantic/citation investigation remains unresolved and is intentionally not changed here.
