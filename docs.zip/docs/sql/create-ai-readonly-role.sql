-- Run as a PostgreSQL administrator using psql.
-- Supply a unique strong password through psql variable substitution:
--   psql "$DB_ADMIN_URL" -v ai_reader_password='YOUR_STRONG_PASSWORD' -f docs/sql/create-ai-readonly-role.sql
-- Replace autoparts_erp_owner below with the actual role that owns application tables.

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'autoparts_ai_reader') THEN
        CREATE ROLE autoparts_ai_reader LOGIN;
    END IF;
END
$$;

-- Set the password separately so it is not embedded in source control.
ALTER ROLE autoparts_ai_reader PASSWORD :'ai_reader_password';

GRANT CONNECT ON DATABASE autoparts_erp TO autoparts_ai_reader;
GRANT USAGE ON SCHEMA public TO autoparts_ai_reader;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO autoparts_ai_reader;

-- Replace autoparts_erp_owner with the actual table-owner role.
ALTER DEFAULT PRIVILEGES FOR ROLE autoparts_erp_owner IN SCHEMA public
    GRANT SELECT ON TABLES TO autoparts_ai_reader;

-- Explicitly revoke write and schema privileges, including accidental grants.
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER
    ON ALL TABLES IN SCHEMA public FROM autoparts_ai_reader;
REVOKE CREATE ON SCHEMA public FROM autoparts_ai_reader;
